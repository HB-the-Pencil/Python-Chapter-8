def format_name(last: str, first: str, middle: str = ""):
    """
    Function that returns a full name, formatted neatly.

    :param last: Last name to be formatted.
    :param first: First name to be formatted.
    :param middle: Middle name (if applicable).

    :return: String containing the capitalized first and last name, and the
        middle name, if there is one.
    """
    if middle:
        full_name = f"{first.title()} {middle.title()} {last.title()}"
    else:
        full_name = f"{first.title()} {last.title()}"

    return full_name

# Ask the user to input their name.
while True:
    print("Input your name to receive a greeting!")
    print("(Type QUIT to quit.)")

    # Get the user's info.
    first_name = input("First name: ").strip()
    if first_name.lower() == "quit":
        break

    last_name = input("Last name: ").strip()
    if last_name.lower() == "quit":
        break

    middle_name = input("Middle name (or leave blank): ").strip()
    if middle_name.lower() == "quit":
        break

    # Print the formatted name.
    print(f"\nHello, {format_name(last_name, first_name, middle_name)}.")