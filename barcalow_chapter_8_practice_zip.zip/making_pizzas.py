# Multiple ways to import functions.

# Way 1:
# import pizza
# pizza.make_pizza(18, "cheese")

# Way 2:
# from pizza import make_pizza
# make_pizza(18, "cheese")

# Way 3:
# from pizza import make_pizza as mp
# mp(18, "cheese")

# Way 4:
# import pizza as p
# p.make_pizza(18, "cheese")

# Way 5:
# from pizza import *
# make_pizza(18, "cheese")