# Let's make some pizza py :D
def make_pizza(size: int, *toppings: str):
    """
    Print the toppings requested for a pizza.

    :param size: Diameter of the pizza (in inches).
    :param toppings: Topping(s) to add to the pizza.

    :return: Prints a bulleted list of toppings.
    """
    print(f"Adding the following toppings to a {size}-inch pizza:")
    for topping in toppings:
        print("  -", topping)
    print()


# These were used for testing, but we don't need them anymore.
# make_pizza(14, "cheese", "pepperoni", "anchovies")
# make_pizza(12, "gorgonzola")