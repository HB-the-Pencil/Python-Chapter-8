def build_person(first: str, last: str, age: int = None):
    """
    Create a dictionary of information about a person.

    :param first: First name of the person.
    :param last: Last name of the person.
    :param age: Age of the person.

    :return: Returns a dictionary with keys corresponding to the inputted
        data.
    """
    person = {"first": first, "last": last}

    # If age is defined, add the person's age.
    if age:
        person["age"] = age

    return person

artist = build_person("nobuo", "uematsu", 65)
print(artist)