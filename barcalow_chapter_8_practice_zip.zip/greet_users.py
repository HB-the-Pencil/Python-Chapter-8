def greet_users(names: list):
    """
    Greet a list of users by name.

    :param names: List of people to be greeted.

    :return: Prints "Hello, {name}!" for each name in the list.
    """

    for name in names:
        print(f"Hello, {name.title()}!")

users = ["todd", "hannah", "michael", "anthony"]
greet_users(users)