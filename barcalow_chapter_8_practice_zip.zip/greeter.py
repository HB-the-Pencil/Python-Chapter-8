def greet_user(username):
    """
    Display a simple greeting.

    :param username: User's name.

    :return: Prints "Hello!"
    """
    print(f"Hello, {username.title()}!")


greet_user("michael jordan")