def describe_pet(pet_name: str, animal_type: str = "dog"):
    """
    Function to describe a pet.

    :param pet_name: The name of the pet.
    :param animal_type: The type of animal that the pet is (dog by default).

    :return: Prints "I have a pet {animal_type} named {pet_name}."
    """

    print(f"I have a pet {animal_type} named {pet_name.title()}.")

describe_pet("samwise", "lynx")
describe_pet(animal_type="wonder hamster", pet_name="harvey")
describe_pet("bork")